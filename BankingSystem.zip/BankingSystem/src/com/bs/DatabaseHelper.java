package com.bs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseHelper {
    private static final String URL = "jdbc:mysql://localhost:3307/BankY";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    private Connection conn;

    public DatabaseHelper() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Ensure this is the correct class name
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Failed to load MySQL driver.", e);
        }
    }

    // Methods for CRUD operations

    public void createAccount(Account account) throws SQLException {
        String sql = "INSERT INTO Account (account_number, account_holder_name, balance) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, account.getAccountNumber());
            pstmt.setString(2, account.getAccountHolderName());
            pstmt.setDouble(3, account.getBalance());
            pstmt.executeUpdate();
    
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    account.setAccountId(generatedKeys.getInt(1));
                }
            }
        }
    }

    public Account getAccount(String accountNumber) throws SQLException {
        String sql = "SELECT * FROM Account WHERE account_number = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, accountNumber);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Account account = new Account(
                            rs.getString("account_number"),
                            rs.getString("account_holder_name"),
                            rs.getDouble("balance")
                    );
                    account.setAccountId(rs.getInt("account_id"));
                    return account;
                }
            }
        }
        return null;
    }

    public void updateAccount(Account account) throws SQLException {
        String sql = "UPDATE Account SET balance = ? WHERE account_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDouble(1, account.getBalance());
            pstmt.setInt(2, account.getAccountId());
            pstmt.executeUpdate();
        }
    }

    public void createTransaction(Transaction transaction) throws SQLException {
        String sql = "INSERT INTO Transaction (account_id, transaction_type, amount) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, transaction.getAccountId());
            pstmt.setString(2, transaction.getTransactionType());
            pstmt.setDouble(3, transaction.getAmount());
            pstmt.executeUpdate();
        }
    }

    public void close() throws SQLException {
        if (conn != null && !conn.isClosed()) {
            conn.close();
        }
    }
}

/* SQL Queries......
CREATE DATABASE BankY;

USE BankY;

CREATE TABLE Account (
    account_id INT AUTO_INCREMENT PRIMARY KEY,
    account_number VARCHAR(20) NOT NULL UNIQUE,
    account_holder_name VARCHAR(100) NOT NULL,
    balance DECIMAL(15, 2) NOT NULL DEFAULT 0.00
);

CREATE TABLE Transaction (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    account_id INT,
    transaction_type ENUM('deposit', 'withdrawal', 'transfer') NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES Account(account_id)
);
*/
