package com.bs;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AccountServlet extends HttpServlet{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        DatabaseHelper dbHelper = null;
        try {
            dbHelper = new DatabaseHelper();
            String message = null;
            if ("create".equals(action)) {
                createAccount(request, dbHelper);
                message = "Account created successfully...";
            } else if ("deposit".equals(action)) {
                depositFunds(request, dbHelper);
                message = "Amount Deposited successfully...";
            } else if ("withdraw".equals(action)) {
                withdrawFunds(request, dbHelper);
                message = "Amount Withdrawn successfully...";
            } else if ("transfer".equals(action)) {
                transferFunds(request, dbHelper);
                message = "Amount Transferred successfully...";
            }
            request.setAttribute("message", message);
            request.getRequestDispatcher("result.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException(e);
        } finally {
            if (dbHelper != null) {
                try {
                    dbHelper.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void createAccount(HttpServletRequest request, DatabaseHelper dbHelper) throws SQLException {
        String accountNumber = request.getParameter("accountNumber");
        String accountHolderName = request.getParameter("accountHolderName");
        double initialBalance = Double.parseDouble(request.getParameter("initialBalance"));
        Account account = new Account(accountNumber, accountHolderName, initialBalance);
        dbHelper.createAccount(account);
    }

    private void depositFunds(HttpServletRequest request, DatabaseHelper dbHelper) throws SQLException {
        String accountNumber = request.getParameter("accountNumber");
        double amount = Double.parseDouble(request.getParameter("amount"));
        Account account = dbHelper.getAccount(accountNumber);
        account.deposit(amount);
        dbHelper.updateAccount(account);
        dbHelper.createTransaction(new Transaction(account.getAccountId(), "deposit", amount));
    }

    private void withdrawFunds(HttpServletRequest request, DatabaseHelper dbHelper) throws SQLException {
        String accountNumber = request.getParameter("accountNumber");
        double amount = Double.parseDouble(request.getParameter("amount"));
        Account account = dbHelper.getAccount(accountNumber);
        if (account.withdraw(amount)) {
            dbHelper.updateAccount(account);
            dbHelper.createTransaction(new Transaction(account.getAccountId(), "withdrawal", amount));
        } else {
            throw new SQLException("Insufficient funds");
        }
    }

    private void transferFunds(HttpServletRequest request, DatabaseHelper dbHelper) throws SQLException {
        String fromAccountNumber = request.getParameter("fromAccountNumber");
        String toAccountNumber = request.getParameter("toAccountNumber");
        double amount = Double.parseDouble(request.getParameter("amount"));
        Account fromAccount = dbHelper.getAccount(fromAccountNumber);
        Account toAccount = dbHelper.getAccount(toAccountNumber);
        if (fromAccount.withdraw(amount)) {
            toAccount.deposit(amount);
            dbHelper.updateAccount(fromAccount);
            dbHelper.updateAccount(toAccount);
            dbHelper.createTransaction(new Transaction(fromAccount.getAccountId(), "transfer", amount));
            dbHelper.createTransaction(new Transaction(toAccount.getAccountId(), "transfer", amount));
        } else {
            throw new SQLException("Insufficient funds");
        }
    }
}
